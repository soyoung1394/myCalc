A Pen created at CodePen.io. You can find this one at http://codepen.io/maxmin93/pen/MpvjBm.

 Daily UI Design Challenge #004 - What's the main focus?
Is it for a book, an album, a mobile app, a product?
Consider important landing page elements
(call-to-actions, clarity, etc.) 